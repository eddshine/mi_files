<?php
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $db = "slambook";
    
	// INSERT DATA
    if(isset($_POST['add-new-data-btn'])) {
		
		$id_data = $_POST['id-data'];
        $name = $_POST['name'];
        $crush = $_POST['crush'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
		$message = $_POST['message'];

        $conn = new mysqli($dbhost, $dbuser, $dbpass,$db);
        
        $sql = "INSERT INTO records (name, crush, age, gender, messages) VALUES ('$name', '$crush', '$age', '$gender', '$message')";
        $rs = mysqli_query($conn, $sql);

        if($rs) {
            header('Location: http://localhost/slambook/');
        }
        mysqli_close($conn);
    }
	
	
	// UPDATE DATA
	if(isset($_POST['edit-data-btn'])) {
		
		$id_data = $_POST['id-data'];
        $name = $_POST['name'];
        $crush = $_POST['crush'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
		$message = $_POST['message'];

        $conn = new mysqli($dbhost, $dbuser, $dbpass,$db);
        
        $sql = "UPDATE records SET 
            name = '$name', 
            crush = '$crush', 
            age = '$age', 
            gender = '$gender', 
            messages = '$message' 
        WHERE id = $id_data";
        $rs = mysqli_query($conn, $sql);

        if($rs) {
            header('Location: http://localhost/slambook/friends.php');
        }
        mysqli_close($conn);
    }
	
	// DELETE DATA
	if(isset($_POST['delsubmitBtn'])) {
		
		$id_data = $_POST['del-id-data'];

        $conn = new mysqli($dbhost, $dbuser, $dbpass,$db);
        
        $sql = "DELETE FROM records WHERE id = $id_data";
        $rs = mysqli_query($conn, $sql);

        if (!$rs) {
            die('Error: ' . mysqli_error($conn)); // Print the error message for debugging
        }else {
            header('Location: http://localhost/slambook/friends.php');
        }
        mysqli_close($conn);
    }

?>