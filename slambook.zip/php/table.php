<?php
    function getTable() {
        $conn = mysqlConnecion();
        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT id, name, crush, age, gender, messages FROM records";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
          // output data of each row
          while($row = $result->fetch_assoc()) {
            echo "<tr class='tableRow'>";
            echo "<td class='table-data-grey table-data data-id'>".$row["id"]."</td>";
            echo "<td class='table-data-white table-data data-name'>".$row["name"]."</td>";
            echo "<td class='table-data-grey table-data data-crush'>".$row["crush"]."</td>";
            echo "<td class='table-data-white table-data data-age'>".$row["age"]." Years old </td>";
            echo "<td class='table-data-grey table-data data-gender'>".$row["gender"]."</td>";
			      echo "<td class='table-data-grey table-data data-message'>".$row["messages"]."</td>";
            echo "<td class='table-btn table-data'><button class='editBtn' title='Modify data'>Edit</button></td>";
            echo "<td class='table-btn table-data'><button type=\"submit\" name=\"delete-data\" form=\"delete-row\" class=\"deleteBtn\" title=\"Delete data\">Delete</button></td>";
            echo "</tr>";
          }
        }
        $conn->close();
    }
?>