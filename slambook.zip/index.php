<?php 
    include 'php/form.php';
    include 'php/connection.php';
    $conn = mysqlConnecion();
    CloseCon($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <title>My Slambook ♥</title>
</head>
<body>
<div class="modal hidden">
        <button class="close-modal" title="Close">&times;</button>
        <h2 id="textAdd">ADD FRIEND</h2>
        <form method="POST" action="php/form.php" id="formModal">
			<div>
                <input type="input" name="id-data" id="id-data" class="formInputs hidden" value="">
            </div>
            <div>
                <input type="input" name="name" id="name" class="formInputs" placeholder="Name">
            </div>
            <div>
                <input type="input" name="crush" id="crush" class="formInputs" placeholder="Crush">
            </div>
            <div>
                <input type="number" name="age" id="age" class="formInputs" placeholder="Age">
            </div>
            <div>
                <select name="gender" id="gender" class="formInputs" title="Gender">
                    <option disabled selected>Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>
			<div>
                <input type="input" name="message" id="message" class="formInputs" placeholder="message">
            </div>
            <div>
                <input type="submit" name="add-new-data-btn" id="submitBtn" class="submitBtn" title="Submit">
            </div>
        </form>
    </div>
    <div class="overlay hidden"></div>
    <h1 id="slambookTextHeader">My Slambook ♥</h1>
    <div class="add-friend">
        <h1 id="addfriendHeader">Add Friend</h1>
        <button class="addBtn" title="Add friend">&plus; Add friend</button>
    </div>
    <div class="view-friend">
        <h1 id="viewfriendHeader">View Friends</h1>
        <button onclick="location.href = 'friends.php';" class="viewBtn" title="View Added Friend">View friends</button>
    </div>
    <script src="js/modal.js"></script>
    <script src="js/table-sorter.js"></script>
    <script src="js/form.js"></script>
</body>
</html>