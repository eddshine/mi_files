<?php 
    include 'php/form.php';
    include 'php/connection.php';
    $conn = mysqlConnecion();
    CloseCon($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <title>My Slambook ♥ - Friends</title>
</head>
<body>
<div class="modal hidden">
        <button class="close-modal" title="Close">&times;</button>
        <h2 id="textAdd">ADD FRIEND</h2>
        <form method="POST" action="php/form.php" id="formModal">
			<div>
                <input type="input" name="id-data" id="id-data" class="formInputs hidden" value="">
            </div>
            <div>
                <input type="input" name="name" id="name" class="formInputs" placeholder="Name">
            </div>
            <div>
                <input type="input" name="crush" id="crush" class="formInputs" placeholder="Crush">
            </div>
            <div>
                <input type="number" name="age" id="age" class="formInputs" placeholder="Age">
            </div>
            <div>
                <select name="gender" id="gender" class="formInputs" title="Gender">
                    <option disabled selected>Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>
			<div>
                <input type="input" name="message" id="message" class="formInputs" placeholder="Message">
            </div>
            <div>
                <input type="submit" name="add-new-data-btn" id="submitBtn" class="submitBtn" title="Submit">
            </div>
        </form>
    </div>
    <div class="del-modal hidden">
        <button class="del-close-modal" title="Close">&times;</button>
        <h2 id="textAdd">DELETE FRIEND?</h2>
        <form method="POST" action="php/form.php" id="delformModal">
			<div>
                <input type="input" name="del-id-data" id="del-id-data" class="delformInputs hidden" value="">
            </div>
            <div id="delbtns">
                <input type="submit" name="delsubmitBtn" id="delsubmitBtn" class="delsubmitBtn" title="Yes">
                <input type="button" name="cancel" id="cancelBtn" class="cancelBtn" title="No" value="Cancel">
            </div>
        </form>
    </div>
    <div class="overlay hidden"></div>
    <h1 id="slambookTextHeader">My Slambook ♥ Friends</h1>
    <section>
        <div class="tableDiv">
            <table class="table">
                <tr>
                    <th class="table-header" title="Click to sort by ID">ID</th>
                    <th class="table-header" title="Click to sort by First Name">First Name</th>
                    <th class="table-header" title="Click to sort by Last Name">Last Name</th>
                    <th class="table-header" title="Click to sort by Age">Age</th>
                    <th class="table-header" title="Click to sort by Gender">Gender</th>
					<th class="table-header" title="Click to sort by Message">Message</th>
                    <th class="table-header" class="editData" title="Edit Data">Edit</th>
                    <th class="table-header">Delete</th>
                </tr>
                    <?php   
                      include 'php/table.php';
                      getTable();
                    ?>
            </table>
        </div>
    </section>

    <button class="goBack" onclick="location.href = 'index.php';" title="Go Back">&plus; Go Back</button>
    <script src="js/friendsmodal.js"></script>
    <script src="js/table-sorter.js"></script>
    <script src="js/form.js"></script>
</body>
</html>