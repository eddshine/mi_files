const modal = document.querySelector('.modal');
const delmodal = document.querySelector('.del-modal');
const overlay = document.querySelector('.overlay');
const closeModal = document.querySelector('.close-modal');
const delcloseModal = document.querySelector('.del-close-modal');
const showModal = document.querySelector('.addBtn');
const cancelBtn = document.querySelector('.cancelBtn');
const editButtons = document.querySelectorAll('.editBtn'); // Select all Edit buttons in your table
const delButtons = document.querySelectorAll('.deleteBtn'); 
const form = document.querySelector('#formModal'); // Select your form element
const delform = document.querySelector('#delformModal'); // Select your form element
const inputElements = modal.querySelectorAll('input.formInputs');
const submitButton = document.getElementById('submitBtn');
const delsubmitButton = document.getElementById('delsubmitBtn');

function closingModal() {
  inputElements.forEach(input => {
        input.value = '';
    });
	
  if (submitButton) {
            // Update the name attribute to "add-new-data-btn"
            submitButton.name = 'add-new-data-btn';
	}
  modal.classList.add('hidden');
  overlay.classList.add('hidden');

}

function openModal() {
  modal.classList.remove('hidden');
  overlay.classList.remove('hidden');
}

function delclosingModal() {
  inputElements.forEach(input => {
        input.value = '';
    });
  delmodal.classList.add('hidden');
  overlay.classList.add('hidden');
}

function delModal() {
  delmodal.classList.remove('hidden');
  overlay.classList.remove('hidden');
}

// Add a click event listener to each Edit button
editButtons.forEach((editButton, index) => {
  editButton.addEventListener('click', () => {
    // Retrieve data from the table row for the clicked Edit button
    const row = editButton.closest('.tableRow');
    const id = row.querySelector('.data-id').textContent;
    const name = row.querySelector('.data-name').textContent;
    const crush = row.querySelector('.data-crush').textContent;
    const age = row.querySelector('.data-age').textContent;
	  const getIntAge = parseInt(age.replace(/\D/g, ''));
    const gender = row.querySelector('.data-gender').textContent;
	  const message = row.querySelector('.data-message').textContent;

    // Set the retrieved data as values in the modal inputs
	  document.querySelector('#id-data').value = id;
    document.querySelector('#name').value = name;
    document.querySelector('#crush').value = crush;
    document.querySelector('#age').value = getIntAge;
    document.querySelector('#gender').value = gender;
	  document.querySelector('#message').value = message;
	
	  if (submitButton) {
            // Update the name attribute to "edit-data-btn"
            submitButton.name = 'edit-data-btn';
	  }

    openModal(); // Open the modal with the retrieved data
  });
});

delButtons.forEach((delButtons, index) => {
  delButtons.addEventListener('click', () => {
    const row = delButtons.closest('.tableRow');
    const id = row.querySelector('.data-id').textContent;

	  document.querySelector('#del-id-data').value = id;
    delModal();
  });
});
cancelBtn.addEventListener('click', delclosingModal);
delcloseModal.addEventListener('click', delclosingModal);
closeModal.addEventListener('click', closingModal);
overlay.addEventListener('click', closingModal);
document.addEventListener('keydown', function (event) {
  if (event.key === 'Escape' && !modal.classList.contains('hidden')) {
    closingModal();
  }
  if (event.key === 'Escape' && !delmodal.classList.contains('hidden')) {
    closingModal();
  }
});

