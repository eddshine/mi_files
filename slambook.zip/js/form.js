const formName = document.getElementById("name");
const formCrush = document.getElementById("crush");
const formAge = document.getElementById("age");
const formGender = document.getElementById("gender");
const formHobby = document.getElementById("hobby");